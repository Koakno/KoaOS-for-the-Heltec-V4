# Sony CCD-FX730V flip-out LCD (PD-53 board): pinout and bench notes

Notes for running the fold-out LCD from a Sony **CCD-FX730V** Video8 Handycam **standalone**, with just a power supply and an RCA composite video source. Most people who reuse parts from these camcorders use the electronic viewfinder (VF-44). This is about the **LCD panel assembly** instead.

> **Status:** community bench notes, not official documentation. Each fact below is marked **Verified** (tested on a real board), **Manual** (taken from the Sony service manual, not independently tested), or **Unknown**. Check before you power anything, and use at your own risk. Not affiliated with Sony.

## What it is

| Item | Detail |
|---|---|
| Camcorder | Sony CCD-FX730V (NTSC, US/Canada/E models) |
| Driver board | **PD-53** ("LCD Video"), Sony part 1-653-928-12 (service part A-7066-157-A) |
| Panel | 3 inch TN LCD, active matrix TFT, 324 x 234 dots (75,816), Sony LCD module 1-810-328-21 |
| Backlight | Fluorescent (cold cathode) tube, driven by an inverter transformer (T002) |
| Video format | **NTSC composite**, about 1.0 Vp-p into 75 ohm |

The panel's standalone-friendly parts (all on the PD-53 board):

| Ref | Part | Job |
|---|---|---|
| IC002 | Sony CXA1785R | Video decoder: composite in, RGB out for the panel |
| IC004 | LZ93BA53 | LCD timing generator |
| IC001 | MB88E346 | Electronic volume (digital pots) for brightness, contrast, etc. |
| IC003 | NJM2406F | Delay |
| IC005 | NJM3414M | Amplifier / low-pass filter |
| IC006, IC007 | TL5001CD | DC/DC converters (make the panel's -8 V and +13 V) |
| X001 | 3.58 MHz crystal | Color subcarrier (NTSC only) |
| PS001 | IC link CCP2E10 | Fuse |
| RV001 | 10 k pot | BRIGHT control (the knob on the housing) |
| RV002 | 1 k trim | Panel -8 V adjustment (leave alone) |

## Safety

- **The backlight inverter produces about 700 Vp-p at 70 kHz** (service manual). Do not touch the tube holders, the tube ends, or the area around the inverter transformer while the board is powered. Wait a minute after power-off.
- The LCD panel is static-sensitive.
- The tube is fragile glass containing mercury. Do not force it.

## Connectors

| Connector | Type | Goes to |
|---|---|---|
| **CN001** | 12-pin white connector (the harness) | Camcorder main side, the SD-14 board's 12-pin **CN502** |
| **CN002** | 10-pin small board-to-board (two rows of 5) | Service test points only |
| W001 / FP-150 | 18-pin flex | The LCD panel itself |

Pin numbers are printed on the board next to each connector.

## CN001 (12-pin) pinout

| Pin | Function | Status |
|---|---|---|
| 1 | not mapped | Unknown |
| 2 | not mapped | Unknown |
| 3 | not mapped | Unknown |
| 4 | not mapped | Unknown |
| **5** | **+5 V ("DAC 5 V")**, manual spec 4.85 +/- 0.05 V | Verified (powered at 5 V) |
| **6** | **Ground** | Verified |
| **7** | **+5 V ("LCD 5 V")**, manual spec 4.85 +/- 0.05 V | Verified (powered at 5 V) |
| 8 | not mapped | Unknown |
| **9** | **Composite video in**, about 1.0 Vp-p (sync at the bottom) | Manual |
| **10** | **"LCD UNREG" supply**, manual spec 6.5 +/- 0.1 V. Also runs from 5 V | Verified at 5 V |
| **11** | **Ground** | Verified |
| 12 | not mapped | Unknown |

Pins 6 and 11 are the grounds. On the SD-14 side, CN502 pins 6 and 11 are tied together on the board and run to the large ground copper.

The camcorder's main board normally sends the panel some control signals. They are among the unmapped pins, and **none were needed for standalone use**.

### Minimal bench wiring

```
5 V supply +  ->  CN001 pins 5, 7 and 10 (tie together)
5 V supply -  ->  CN001 pins 6 and 11 (tie together)  ->  also the video source's ground
Video source  ->  CN001 pin 9 (composite, about 1 Vp-p)
```

With only power connected, the **backlight comes on**. Add a video signal and the picture appears.

## CN002 (10-pin) service test connector

From the manual's adjustment table. These are **measurement points, not inputs**. Do not drive them.

| Pin | Signal | Pin | Signal |
|---|---|---|---|
| 1 | VB (blue drive) | 2 | -8 V (panel supply) |
| 3 | VG (green drive) | 4 | +13 V (panel supply) |
| 5 | VR (red drive) | 6 | SPD |
| 7 | SYNC (H sync) | 8 | HSY (active-low H sync; VCO frequency test point) |
| 9 | GND | 10 | GND |

The manual's service procedure puts the horizontal VCO at **15,734 +/- 30 Hz** (measured on pin 8 with no video).

## Power

- **5 V on pins 5, 7 and 10 worked.** The manual wants 6.5 V on pin 10, but at 5 V the backlight was bright enough in testing.
- Supply current was **not measured**. Use a supply that can give at least about 1 A, since the backlight inverter pulls more than the logic.
- Standalone, the board powers up without any enable signal. In the camcorder, the display only turns on when the panel is opened.

## Video

- **NTSC only.** The color decoder uses a 3.58 MHz crystal.
- Standard level is 1 Vp-p (about 0.286 V sync and 0.714 V picture) into 75 ohm.
- Sources that worked in testing: a VCR, and an ESP8266 generating composite video (see [WeatherClock](WeatherClock-README.md)).

## The big gotcha: ground

**Use pins 6 and 11 as ground. Do not use the chassis ground lug on the board.**

Symptom of a bad ground: with power and a source connected, the picture **rolls vertically, about once per second, with snow and colored dots, whether or not video is connected**.

In testing, grounding through the chassis lug gave exactly that. Tying pins 6 and 11 to ground fixed it immediately, with clear contrast and no further adjustment. The decoder needs the board's own signal ground as its reference.

## Controls and adjustments

- **RV001 (BRIGHT)** is the 10 k pot on the board that the housing's knob turns. The service manual sets it to its center click for alignment.
- The panel's other settings (contrast, white balance, VCO, VCOM, horizontal position) are set by IC001, which the camcorder programs at startup. **The board worked well with none of that, so defaults appear usable.** If you need to tune them, the manual's reference values are below.

### Reference only: service-manual EVR values (page D)

| Address | Setting | Default |
|---|---|---|
| B0 | BRIGHT | 55 |
| B1 | (not named) | 90 |
| B2 | (not named) | 95 |
| B3 | SUB BRI R (white balance) | A2 |
| B4 | SUB BRI B (white balance) | 70 |
| B5 | CONTRAST | 99 |
| B6 | VCO | CD |
| B7 | VCOM | 7B |
| B8 | (not named) | 6B |
| B9 | (not named) | 78 |
| BA | H POSITION | B7 |
| BB | (not named) | 92 |

How these get written into IC001 (the serial bus lines) is **not mapped**. They are presumably on the unknown CN001 pins.

## Open questions

- What are CN001 pins 1, 2, 3, 4, 8 and 12? The serial lines for the electronic volume and the panel enable are likely among them.
- Does this need 6.5 V on pin 10 for full backlight brightness?
- Current draw at 5 V.

If you work any of these out, please add them here.

## Sources

- Sony CCD-FX730V service manual (9-973-606-11), PD-53 board sections: LCD system adjustments, parts list, disassembly.
- Bench testing by the author.
