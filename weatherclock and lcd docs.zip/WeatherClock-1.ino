/*
  WeatherClock.ino
  ESP8266 weather + clock dashboard, set up over the serial port.

  - Serial: 115200 baud (picocom -b 115200 /dev/ttyUSB0  or  screen /dev/ttyUSB0 115200)
  - Type "help" for the command list.
  - Weather and geocoding: Open-Meteo (free, no API key). Time: NTP.
  - Needs ESP8266 Arduino core 2.5 or newer (HTTPS via BearSSL).

  The dashboard is built into a 32x12 text buffer (screenBuf). 

  GPIO3 is also the serial RX pin, so on boot there is a 5 second setup window:
  press Enter in it to keep serial input (video stays off until you type "video").
  Otherwise video starts and serial input stops until the next reset.
*/

#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>
#include <EEPROM.h>
#include <time.h>

#define ROWS 12
#define COLS 32

const unsigned long REFRESH_MS = 15UL * 60UL * 1000UL;   // weather refresh: 15 min
const uint32_t CFG_MAGIC = 0x57583031;

struct Config {
  uint32_t magic;
  char ssid[33];
  char pass[65];
  char city[40];
  char state[32];
  char country[32];
  float lat;
  float lon;
  uint8_t haveLoc;
  uint8_t fahrenheit;
};
Config cfg;

// ---------- weather state ----------
bool haveWx = false;
float curTemp = 0;
int curCode = 0;
int dayCode[4], dayHi[4], dayLo[4], dayDow[4];
int dayCount = 0;
long utcOffset = 0;
String wxStatus = "Loading weather...";

// ---------- screen text buffer ----------
char screenBuf[ROWS][COLS + 1];

// ---------- runtime state ----------
String lineBuf;
bool liveMode = false;
bool needGeocode = false;
bool forceRefresh = false;
bool wasConnected = false;
bool triedWifi = false;
unsigned long lastWifiTry = 0;
unsigned long nextFetchAt = 0;
unsigned long lastDraw = 0;

const char* const DAYS[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
const char* const MONTHS[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

const char* const US_STATES[] = {
  "AL", "Alabama", "AK", "Alaska", "AZ", "Arizona", "AR", "Arkansas",
  "CA", "California", "CO", "Colorado", "CT", "Connecticut", "DE", "Delaware",
  "DC", "District of Columbia", "FL", "Florida", "GA", "Georgia", "HI", "Hawaii",
  "ID", "Idaho", "IL", "Illinois", "IN", "Indiana", "IA", "Iowa",
  "KS", "Kansas", "KY", "Kentucky", "LA", "Louisiana", "ME", "Maine",
  "MD", "Maryland", "MA", "Massachusetts", "MI", "Michigan", "MN", "Minnesota",
  "MS", "Mississippi", "MO", "Missouri", "MT", "Montana", "NE", "Nebraska",
  "NV", "Nevada", "NH", "New Hampshire", "NJ", "New Jersey", "NM", "New Mexico",
  "NY", "New York", "NC", "North Carolina", "ND", "North Dakota", "OH", "Ohio",
  "OK", "Oklahoma", "OR", "Oregon", "PA", "Pennsylvania", "RI", "Rhode Island",
  "SC", "South Carolina", "SD", "South Dakota", "TN", "Tennessee", "TX", "Texas",
  "UT", "Utah", "VT", "Vermont", "VA", "Virginia", "WA", "Washington",
  "WV", "West Virginia", "WI", "Wisconsin", "WY", "Wyoming"
};
const int NUM_STATES = sizeof(US_STATES) / sizeof(US_STATES[0]) / 2;

// =====================================================================
// Small helpers
// =====================================================================

void copyStr(char* dst, size_t n, const String& src) {
  strncpy(dst, src.c_str(), n - 1);
  dst[n - 1] = 0;
}

void saveConfig() {
  EEPROM.put(0, cfg);
  EEPROM.commit();
}

void loadConfig() {
  EEPROM.get(0, cfg);
  if (cfg.magic != CFG_MAGIC) {
    memset(&cfg, 0, sizeof(cfg));
    cfg.magic = CFG_MAGIC;
    cfg.fahrenheit = 1;
    saveConfig();
  }
  cfg.ssid[sizeof(cfg.ssid) - 1] = 0;
  cfg.pass[sizeof(cfg.pass) - 1] = 0;
  cfg.city[sizeof(cfg.city) - 1] = 0;
  cfg.state[sizeof(cfg.state) - 1] = 0;
  cfg.country[sizeof(cfg.country) - 1] = 0;
}

// Value after "key": (quoted string without quotes, or a bare number)
String getVal(const String& s, const char* key, int from) {
  String k = String("\"") + key + "\":";
  int i = s.indexOf(k, from);
  if (i < 0) return "";
  i += k.length();
  while (i < (int)s.length() && s[i] == ' ') i++;
  if (i >= (int)s.length()) return "";
  if (s[i] == '"') {
    int j = s.indexOf('"', i + 1);
    if (j < 0) return "";
    return s.substring(i + 1, j);
  }
  int j = i;
  while (j < (int)s.length() && s[j] != ',' && s[j] != '}' && s[j] != ']') j++;
  return s.substring(i, j);
}

String getVal(const String& s, const char* key) {
  return getVal(s, key, 0);
}

int getNumArray(const String& s, const char* key, int from, float* out, int n) {
  String k = String("\"") + key + "\":[";
  int i = s.indexOf(k, from);
  if (i < 0) return 0;
  i += k.length();
  int count = 0;
  while (count < n) {
    int j = i;
    while (j < (int)s.length() && s[j] != ',' && s[j] != ']') j++;
    out[count++] = s.substring(i, j).toFloat();
    if (j >= (int)s.length() || s[j] == ']') break;
    i = j + 1;
  }
  return count;
}

int getStrArray(const String& s, const char* key, int from, String* out, int n) {
  String k = String("\"") + key + "\":[";
  int i = s.indexOf(k, from);
  if (i < 0) return 0;
  i += k.length();
  int count = 0;
  while (count < n) {
    int j = i;
    while (j < (int)s.length() && s[j] != ',' && s[j] != ']') j++;
    String tok = s.substring(i, j);
    tok.replace("\"", "");
    tok.trim();
    out[count++] = tok;
    if (j >= (int)s.length() || s[j] == ']') break;
    i = j + 1;
  }
  return count;
}

String urlEncode(const String& s) {
  String out;
  const char* hex = "0123456789ABCDEF";
  for (unsigned int i = 0; i < s.length(); i++) {
    char c = s[i];
    if (isalnum((unsigned char)c) || c == '-' || c == '_' || c == '.' || c == '~') {
      out += c;
    } else {
      out += '%';
      out += hex[(c >> 4) & 0xF];
      out += hex[c & 0xF];
    }
  }
  return out;
}

String expandState(String s) {
  s.trim();
  if (s.length() != 2) return s;
  for (int i = 0; i < NUM_STATES; i++) {
    if (s.equalsIgnoreCase(US_STATES[i * 2])) return String(US_STATES[i * 2 + 1]);
  }
  return s;
}

// 0 = Sunday
int dayOfWeek(int y, int m, int d) {
  static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
  if (m < 3) y -= 1;
  return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
}

const char* codeText(int c) {
  if (c == 0) return "Clear";
  if (c == 1 || c == 2) return "Partly cloudy";
  if (c == 3) return "Overcast";
  if (c == 45 || c == 48) return "Fog";
  if (c >= 51 && c <= 57) return "Drizzle";
  if (c >= 61 && c <= 67) return "Rain";
  if (c >= 71 && c <= 77) return "Snow";
  if (c >= 80 && c <= 82) return "Showers";
  if (c == 85 || c == 86) return "Snow showers";
  if (c >= 95) return "Thunderstorm";
  return "?";
}

bool clockValid() {
  return time(nullptr) > 1700000000UL;
}

time_t localNow() {
  return time(nullptr) + utcOffset;
}

// =====================================================================
// Network
// =====================================================================

bool httpGet(const String& url, String& body) {
  BearSSL::WiFiClientSecure client;
  client.setInsecure();
  // The video buffers use ~19 KB of RAM, which can leave too little for the
  // default 16 KB TLS buffers. If the server supports it, use small ones.
  int hs = url.indexOf("://");
  int he = url.indexOf('/', hs + 3);
  String host = url.substring(hs + 3, he < 0 ? url.length() : he);
  Serial.printf("Free heap %u, largest block %u\r\n", ESP.getFreeHeap(),
                ESP.getMaxFreeBlockSize());
  if (client.probeMaxFragmentLength(host, 443, 1024)) {
    client.setBufferSizes(1024, 1024);
  } else {
    Serial.println("Server has no small-buffer mode; using full TLS buffers.");
  }
  HTTPClient http;
  http.setTimeout(10000);
  if (!http.begin(client, url)) {
    Serial.println("HTTP begin failed");
    return false;
  }
  int code = http.GET();
  if (code != HTTP_CODE_OK) {
    Serial.printf("HTTP error: %d (%s)\r\n", code, http.errorToString(code).c_str());
    http.end();
    return false;
  }
  body = http.getString();
  http.end();
  return body.length() > 0;
}

bool geocode() {
  if (!cfg.city[0]) return false;
  Serial.printf("Looking up %s...\r\n", cfg.city);
  String url = String("https://geocoding-api.open-meteo.com/v1/search?name=") +
               urlEncode(String(cfg.city)) + "&count=10&language=en&format=json";
  String body;
  if (!httpGet(url, body)) return false;

  int rp = body.indexOf("\"results\":[");
  if (rp < 0) {
    Serial.println("No match for that city name.");
    return false;
  }

  String wantState = expandState(String(cfg.state));
  wantState.trim();
  wantState.toLowerCase();
  String wantCountry = String(cfg.country);
  wantCountry.trim();
  wantCountry.toLowerCase();
  if (wantCountry == "usa") wantCountry = "us";

  int pos = body.indexOf("{\"id\":", rp);
  bool haveFirst = false, matched = false;
  float firstLat = 0, firstLon = 0, useLat = 0, useLon = 0;
  String firstDesc, useDesc;

  while (pos >= 0) {
    int next = body.indexOf("{\"id\":", pos + 6);
    String obj = (next < 0) ? body.substring(pos) : body.substring(pos, next);
    float la = getVal(obj, "latitude").toFloat();
    float lo = getVal(obj, "longitude").toFloat();
    String admin1 = getVal(obj, "admin1");
    String cc = getVal(obj, "country_code");
    String country = getVal(obj, "country");
    String desc = getVal(obj, "name") + ", " + admin1 + ", " + cc;

    if (!haveFirst) {
      haveFirst = true;
      firstLat = la;
      firstLon = lo;
      firstDesc = desc;
    }

    String a1 = admin1;
    a1.toLowerCase();
    String c1 = cc;
    c1.toLowerCase();
    String c2 = country;
    c2.toLowerCase();

    bool stateOk = (wantState.length() == 0) || (a1 == wantState);
    bool countryOk = (wantCountry.length() == 0) || (c1 == wantCountry) ||
                     (c2 == wantCountry) ||
                     (c2.length() > 0 && wantCountry.startsWith(c2));
    if (stateOk && countryOk) {
      matched = true;
      useLat = la;
      useLon = lo;
      useDesc = desc;
      break;
    }
    pos = next;
  }

  if (!haveFirst) {
    Serial.println("No results.");
    return false;
  }
  if (!matched) {
    Serial.println("No exact state/country match, using the first result.");
    useLat = firstLat;
    useLon = firstLon;
    useDesc = firstDesc;
  }

  cfg.lat = useLat;
  cfg.lon = useLon;
  cfg.haveLoc = 1;
  saveConfig();
  Serial.printf("Found: %s (%.4f, %.4f)\r\n", useDesc.c_str(), useLat, useLon);
  return true;
}

bool fetchWeather() {
  String url = String("https://api.open-meteo.com/v1/forecast?latitude=") +
               String(cfg.lat, 4) + "&longitude=" + String(cfg.lon, 4) +
               "&current=temperature_2m,weather_code" +
               "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
               "&temperature_unit=" + (cfg.fahrenheit ? "fahrenheit" : "celsius") +
               "&timezone=auto&forecast_days=4";
  String body;
  if (!httpGet(url, body)) {
    wxStatus = "Weather update failed";
    return false;
  }

  int cp = body.indexOf("\"current\":");
  int dp = body.indexOf("\"daily\":");
  if (cp < 0 || dp < 0) {
    wxStatus = "Bad weather data";
    return false;
  }

  utcOffset = getVal(body, "utc_offset_seconds").toInt();
  curTemp = getVal(body, "temperature_2m", cp).toFloat();
  curCode = getVal(body, "weather_code", cp).toInt();

  String dates[4];
  float codes[4], hi[4], lo[4];
  int n = getStrArray(body, "time", dp, dates, 4);
  int nc = getNumArray(body, "weather_code", dp, codes, 4);
  int nh = getNumArray(body, "temperature_2m_max", dp, hi, 4);
  int nl = getNumArray(body, "temperature_2m_min", dp, lo, 4);
  if (nc < n) n = nc;
  if (nh < n) n = nh;
  if (nl < n) n = nl;
  if (n < 1) {
    wxStatus = "Bad forecast data";
    return false;
  }

  for (int i = 0; i < n; i++) {
    dayCode[i] = (int)codes[i];
    dayHi[i] = (int)lroundf(hi[i]);
    dayLo[i] = (int)lroundf(lo[i]);
    int y = dates[i].substring(0, 4).toInt();
    int m = dates[i].substring(5, 7).toInt();
    int d = dates[i].substring(8, 10).toInt();
    if (m < 1 || m > 12) m = 1;
    dayDow[i] = dayOfWeek(y, m, d);
  }
  dayCount = n;
  haveWx = true;
  wxStatus = "";
  Serial.println("Weather updated.");
  return true;
}

// =====================================================================
// Screen
// =====================================================================

String placeName() {
  if (cfg.city[0]) {
    String p = String(cfg.city);
    if (cfg.state[0]) {
      p += ", ";
      p += cfg.state;
    }
    return p;
  }
  if (cfg.haveLoc) return String(cfg.lat, 2) + "," + String(cfg.lon, 2);
  return "No location";
}

String statusLine() {
  if (!cfg.ssid[0]) return "No WiFi set - type help";
  if (WiFi.status() != WL_CONNECTED) return "WiFi connecting...";
  if (!cfg.haveLoc) return "No location - type help";
  return wxStatus;
}

void clearScreenBuf() {
  for (int r = 0; r < ROWS; r++) {
    memset(screenBuf[r], ' ', COLS);
    screenBuf[r][COLS] = 0;
  }
}

void putText(int row, int col, const char* text) {
  if (row < 0 || row >= ROWS) return;
  for (int i = 0; text[i] && col + i < COLS; i++) {
    if (col + i >= 0) screenBuf[row][col + i] = text[i];
  }
}

void centerText(int row, const char* text) {
  int col = (COLS - (int)strlen(text)) / 2;
  if (col < 0) col = 0;
  putText(row, col, text);
}

void buildScreen() {
  clearScreenBuf();
#if VIDEO_TEST_PATTERN
  for (int r = 0; r < ROWS; r++) {
    for (int c = 0; c < COLS; c++) {
      screenBuf[r][c] = (r == 0 || r == ROWS - 1) ? '#' : (char)(33 + (r * 7 + c) % 94);
    }
  }
  return;
#endif
  char line[64];
  char u = cfg.fahrenheit ? 'F' : 'C';

  centerText(0, placeName().c_str());

  if (clockValid()) {
    time_t t = localNow();
    struct tm tmv;
    gmtime_r(&t, &tmv);
    int h12 = tmv.tm_hour % 12;
    if (h12 == 0) h12 = 12;
    snprintf(line, sizeof(line), "%d:%02d:%02d %s", h12, tmv.tm_min, tmv.tm_sec,
             tmv.tm_hour < 12 ? "AM" : "PM");
    centerText(2, line);
    snprintf(line, sizeof(line), "%s %s %d %d", DAYS[tmv.tm_wday], MONTHS[tmv.tm_mon],
             tmv.tm_mday, tmv.tm_year + 1900);
    centerText(3, line);
  } else {
    centerText(2, "Setting clock...");
  }

  if (haveWx) {
    snprintf(line, sizeof(line), "NOW %d%c %s", (int)lroundf(curTemp), u, codeText(curCode));
    centerText(5, line);
    snprintf(line, sizeof(line), "Today %d/%d %s", dayHi[0], dayLo[0], codeText(dayCode[0]));
    centerText(6, line);
    for (int i = 1; i < dayCount && i < 4; i++) {
      snprintf(line, sizeof(line), "%s %d/%d %s", DAYS[dayDow[i]], dayHi[i], dayLo[i],
               codeText(dayCode[i]));
      putText(7 + i, 1, line);
    }
  }

  String st = statusLine();
  if (st.length()) putText(11, 0, st.c_str());
}

void printScreen(bool clearFirst) {
  if (clearFirst) Serial.print("\033[2J\033[H");
  Serial.print('+');
  for (int i = 0; i < COLS; i++) Serial.print('-');
  Serial.println('+');
  for (int r = 0; r < ROWS; r++) {
    Serial.print('|');
    Serial.print(screenBuf[r]);
    Serial.println('|');
  }
  Serial.print('+');
  for (int i = 0; i < COLS; i++) Serial.print('-');
  Serial.println('+');
}

// =====================================================================
// Composite video out (monochrome NTSC-style, 262 lines, ~59.6 Hz)
//
// How it works: the I2S transmitter is fed by the SLC DMA engine from a
// ring of 262 descriptors (one per scanline). The ring runs forever on
// its own, so WiFi / HTTPS / delay() never disturb the picture. The CPU
// only rewrites a character cell in RAM when the text changes.
//
//   bit clock   : 160 MHz / (VID_BCK_DIV * VID_CLKM_DIV) = 20 Mbit/s
//   scanline    : 40 words x 32 bits = 1280 bits = 64.0 us (15.625 kHz)
//   pixel       : 4 bits (200 ns) -> 256 px across = 32 chars x 8 px
//   one word of the active region = one character cell, one scanline
//
// The single GPIO3 pin makes 3 voltage levels by pulse density; a small
// low-pass filter on the RCA jack turns the bit stream into voltage:
//   sync tip   0000  -> 0 V
//   black      0101  -> ~50 % (10 MHz ripple that the filter must kill)
//   white      1111  -> 100 %
//
// Output pin: GPIO3 (the RX pin). While video runs, serial INPUT is gone
// (serial output on GPIO1 still works). See the setup window in setup().
//
// 8x8 font data derived from the CP437 font in luma.core (MIT license).
// =====================================================================

#define VIDEO_TEST_PATTERN 0      // 1 = show a character grid instead of the weather

#define VID_BCK_DIV    2          // bit clock = 160 MHz / (BCK_DIV * CLKM_DIV)
#define VID_CLKM_DIV   4          //           = 20 MHz
#define VID_WORDS      40         // 32-bit words per scanline (64.0 us)
#define VID_LINES      262
#define VID_SYNC_W     3          // 4.8 us sync pulse
#define VID_BP_W       4          // 6.4 us back porch
#define VID_ACT_W      (VID_SYNC_W + VID_BP_W)   // first active word (11.2 us)
#define VID_VSYNC_LINES 3
#define VID_ACTIVE_FIRST 34       // first visible scanline
#define VID_TEXT_LINES (ROWS * 8)                // 96 unique scanlines, each drawn twice

#define VID_NIB_BLACK  0x5        // 0101 = 50 % density. 0x4/0x2 = darker but lower-frequency ripple
#define VID_NIB_WHITE  0xF

// If the picture is garbled, flip these (they only change bit order in each DMA word):
#define VID_REVERSE_BITS 0        // 1 if every character looks mirrored
#define VID_SWAP_HALVES  0        // 1 if each half of a character looks swapped

struct VidDesc {
  uint32_t blocksize : 12;
  uint32_t datalen   : 12;
  uint32_t unused    : 5;
  uint32_t sub_sof   : 1;
  uint32_t eof       : 1;
  volatile uint32_t owner : 1;
  uint32_t *buf_ptr;
  struct VidDesc *next_link_ptr;
};

static VidDesc  vidDesc[VID_LINES];
static VidDesc  vidDummy;                       // unused SLC "TX" descriptor the engine insists on
static uint32_t vidDummyBuf[4];
static uint32_t vidBlank[VID_WORDS];
static uint32_t vidVsync[VID_WORDS];
static uint32_t vidText[VID_TEXT_LINES][VID_WORDS];
static char     vidShadow[ROWS][COLS];
static bool     vidRunning = false;
unsigned long   lastVid = 0;

static const uint8_t VID_FONT[95 * 8] PROGMEM = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ' '
  0x30, 0x78, 0x78, 0x30, 0x30, 0x00, 0x30, 0x00,  // '!'
  0x6C, 0x6C, 0x6C, 0x00, 0x00, 0x00, 0x00, 0x00,  // '"'
  0x6C, 0x6C, 0xFE, 0x6C, 0xFE, 0x6C, 0x6C, 0x00,  // '#'
  0x30, 0x7C, 0xC0, 0x78, 0x0C, 0xF8, 0x30, 0x00,  // '$'
  0x00, 0xC6, 0xCC, 0x18, 0x30, 0x66, 0xC6, 0x00,  // '%'
  0x38, 0x6C, 0x38, 0x76, 0xDC, 0xCC, 0x76, 0x00,  // '&'
  0x60, 0x60, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00,  // '''
  0x18, 0x30, 0x60, 0x60, 0x60, 0x30, 0x18, 0x00,  // '('
  0x60, 0x30, 0x18, 0x18, 0x18, 0x30, 0x60, 0x00,  // ')'
  0x00, 0x66, 0x3C, 0xFF, 0x3C, 0x66, 0x00, 0x00,  // '*'
  0x00, 0x30, 0x30, 0xFC, 0x30, 0x30, 0x00, 0x00,  // '+'
  0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x30, 0x60,  // ','
  0x00, 0x00, 0x00, 0xFC, 0x00, 0x00, 0x00, 0x00,  // '-'
  0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x30, 0x00,  // '.'
  0x06, 0x0C, 0x18, 0x30, 0x60, 0xC0, 0x80, 0x00,  // '/'
  0x7C, 0xC6, 0xCE, 0xDE, 0xF6, 0xE6, 0x7C, 0x00,  // '0'
  0x30, 0x70, 0x30, 0x30, 0x30, 0x30, 0xFC, 0x00,  // '1'
  0x78, 0xCC, 0x0C, 0x38, 0x60, 0xCC, 0xFC, 0x00,  // '2'
  0x78, 0xCC, 0x0C, 0x38, 0x0C, 0xCC, 0x78, 0x00,  // '3'
  0x1C, 0x3C, 0x6C, 0xCC, 0xFE, 0x0C, 0x1E, 0x00,  // '4'
  0xFC, 0xC0, 0xF8, 0x0C, 0x0C, 0xCC, 0x78, 0x00,  // '5'
  0x38, 0x60, 0xC0, 0xF8, 0xCC, 0xCC, 0x78, 0x00,  // '6'
  0xFC, 0xCC, 0x0C, 0x18, 0x30, 0x30, 0x30, 0x00,  // '7'
  0x78, 0xCC, 0xCC, 0x78, 0xCC, 0xCC, 0x78, 0x00,  // '8'
  0x78, 0xCC, 0xCC, 0x7C, 0x0C, 0x18, 0x70, 0x00,  // '9'
  0x00, 0x30, 0x30, 0x00, 0x00, 0x30, 0x30, 0x00,  // ':'
  0x00, 0x30, 0x30, 0x00, 0x00, 0x30, 0x30, 0x60,  // ';'
  0x18, 0x30, 0x60, 0xC0, 0x60, 0x30, 0x18, 0x00,  // '<'
  0x00, 0x00, 0xFC, 0x00, 0x00, 0xFC, 0x00, 0x00,  // '='
  0x60, 0x30, 0x18, 0x0C, 0x18, 0x30, 0x60, 0x00,  // '>'
  0x78, 0xCC, 0x0C, 0x18, 0x30, 0x00, 0x30, 0x00,  // '?'
  0x7C, 0xC6, 0xDE, 0xDE, 0xDE, 0xC0, 0x78, 0x00,  // '@'
  0x30, 0x78, 0xCC, 0xCC, 0xFC, 0xCC, 0xCC, 0x00,  // 'A'
  0xFC, 0x66, 0x66, 0x7C, 0x66, 0x66, 0xFC, 0x00,  // 'B'
  0x3C, 0x66, 0xC0, 0xC0, 0xC0, 0x66, 0x3C, 0x00,  // 'C'
  0xF8, 0x6C, 0x66, 0x66, 0x66, 0x6C, 0xF8, 0x00,  // 'D'
  0xFE, 0x62, 0x68, 0x78, 0x68, 0x62, 0xFE, 0x00,  // 'E'
  0xFE, 0x62, 0x68, 0x78, 0x68, 0x60, 0xF0, 0x00,  // 'F'
  0x3C, 0x66, 0xC0, 0xC0, 0xCE, 0x66, 0x3E, 0x00,  // 'G'
  0xCC, 0xCC, 0xCC, 0xFC, 0xCC, 0xCC, 0xCC, 0x00,  // 'H'
  0x78, 0x30, 0x30, 0x30, 0x30, 0x30, 0x78, 0x00,  // 'I'
  0x1E, 0x0C, 0x0C, 0x0C, 0xCC, 0xCC, 0x78, 0x00,  // 'J'
  0xE6, 0x66, 0x6C, 0x78, 0x6C, 0x66, 0xE6, 0x00,  // 'K'
  0xF0, 0x60, 0x60, 0x60, 0x62, 0x66, 0xFE, 0x00,  // 'L'
  0xC6, 0xEE, 0xFE, 0xFE, 0xD6, 0xC6, 0xC6, 0x00,  // 'M'
  0xC6, 0xE6, 0xF6, 0xDE, 0xCE, 0xC6, 0xC6, 0x00,  // 'N'
  0x38, 0x6C, 0xC6, 0xC6, 0xC6, 0x6C, 0x38, 0x00,  // 'O'
  0xFC, 0x66, 0x66, 0x7C, 0x60, 0x60, 0xF0, 0x00,  // 'P'
  0x78, 0xCC, 0xCC, 0xCC, 0xDC, 0x78, 0x1C, 0x00,  // 'Q'
  0xFC, 0x66, 0x66, 0x7C, 0x6C, 0x66, 0xE6, 0x00,  // 'R'
  0x78, 0xCC, 0xE0, 0x70, 0x1C, 0xCC, 0x78, 0x00,  // 'S'
  0xFC, 0xB4, 0x30, 0x30, 0x30, 0x30, 0x78, 0x00,  // 'T'
  0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xFC, 0x00,  // 'U'
  0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0x78, 0x30, 0x00,  // 'V'
  0xC6, 0xC6, 0xC6, 0xD6, 0xFE, 0xEE, 0xC6, 0x00,  // 'W'
  0xC6, 0xC6, 0x6C, 0x38, 0x38, 0x6C, 0xC6, 0x00,  // 'X'
  0xCC, 0xCC, 0xCC, 0x78, 0x30, 0x30, 0x78, 0x00,  // 'Y'
  0xFE, 0xC6, 0x8C, 0x18, 0x32, 0x66, 0xFE, 0x00,  // 'Z'
  0x78, 0x60, 0x60, 0x60, 0x60, 0x60, 0x78, 0x00,  // '['
  0xC0, 0x60, 0x30, 0x18, 0x0C, 0x06, 0x02, 0x00,  // '\\'
  0x78, 0x18, 0x18, 0x18, 0x18, 0x18, 0x78, 0x00,  // ']'
  0x10, 0x38, 0x6C, 0xC6, 0x00, 0x00, 0x00, 0x00,  // '^'
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF,  // '_'
  0x30, 0x30, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00,  // '`'
  0x00, 0x00, 0x78, 0x0C, 0x7C, 0xCC, 0x76, 0x00,  // 'a'
  0xE0, 0x60, 0x60, 0x7C, 0x66, 0x66, 0xDC, 0x00,  // 'b'
  0x00, 0x00, 0x78, 0xCC, 0xC0, 0xCC, 0x78, 0x00,  // 'c'
  0x1C, 0x0C, 0x0C, 0x7C, 0xCC, 0xCC, 0x76, 0x00,  // 'd'
  0x00, 0x00, 0x78, 0xCC, 0xFC, 0xC0, 0x78, 0x00,  // 'e'
  0x38, 0x6C, 0x60, 0xF0, 0x60, 0x60, 0xF0, 0x00,  // 'f'
  0x00, 0x00, 0x76, 0xCC, 0xCC, 0x7C, 0x0C, 0xF8,  // 'g'
  0xE0, 0x60, 0x6C, 0x76, 0x66, 0x66, 0xE6, 0x00,  // 'h'
  0x30, 0x00, 0x70, 0x30, 0x30, 0x30, 0x78, 0x00,  // 'i'
  0x0C, 0x00, 0x0C, 0x0C, 0x0C, 0xCC, 0xCC, 0x78,  // 'j'
  0xE0, 0x60, 0x66, 0x6C, 0x78, 0x6C, 0xE6, 0x00,  // 'k'
  0x70, 0x30, 0x30, 0x30, 0x30, 0x30, 0x78, 0x00,  // 'l'
  0x00, 0x00, 0xCC, 0xFE, 0xFE, 0xD6, 0xC6, 0x00,  // 'm'
  0x00, 0x00, 0xF8, 0xCC, 0xCC, 0xCC, 0xCC, 0x00,  // 'n'
  0x00, 0x00, 0x78, 0xCC, 0xCC, 0xCC, 0x78, 0x00,  // 'o'
  0x00, 0x00, 0xDC, 0x66, 0x66, 0x7C, 0x60, 0xF0,  // 'p'
  0x00, 0x00, 0x76, 0xCC, 0xCC, 0x7C, 0x0C, 0x1E,  // 'q'
  0x00, 0x00, 0xDC, 0x76, 0x66, 0x60, 0xF0, 0x00,  // 'r'
  0x00, 0x00, 0x7C, 0xC0, 0x78, 0x0C, 0xF8, 0x00,  // 's'
  0x10, 0x30, 0x7C, 0x30, 0x30, 0x34, 0x18, 0x00,  // 't'
  0x00, 0x00, 0xCC, 0xCC, 0xCC, 0xCC, 0x76, 0x00,  // 'u'
  0x00, 0x00, 0xCC, 0xCC, 0xCC, 0x78, 0x30, 0x00,  // 'v'
  0x00, 0x00, 0xC6, 0xD6, 0xFE, 0xFE, 0x6C, 0x00,  // 'w'
  0x00, 0x00, 0xC6, 0x6C, 0x38, 0x6C, 0xC6, 0x00,  // 'x'
  0x00, 0x00, 0xCC, 0xCC, 0xCC, 0x7C, 0x0C, 0xF8,  // 'y'
  0x00, 0x00, 0xFC, 0x98, 0x30, 0x64, 0xFC, 0x00,  // 'z'
  0x1C, 0x30, 0x30, 0xE0, 0x30, 0x30, 0x1C, 0x00,  // '{'
  0x18, 0x18, 0x18, 0x00, 0x18, 0x18, 0x18, 0x00,  // '|'
  0xE0, 0x30, 0x30, 0x1C, 0x30, 0x30, 0xE0, 0x00,  // '}'
  0x76, 0xDC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // '~'
};

static inline uint32_t vidFix(uint32_t w) {
#if VID_REVERSE_BITS
  w = ((w >> 1) & 0x55555555u) | ((w & 0x55555555u) << 1);
  w = ((w >> 2) & 0x33333333u) | ((w & 0x33333333u) << 2);
  w = ((w >> 4) & 0x0F0F0F0Fu) | ((w & 0x0F0F0F0Fu) << 4);
  w = ((w >> 8) & 0x00FF00FFu) | ((w & 0x00FF00FFu) << 8);
  w = (w >> 16) | (w << 16);
#endif
#if VID_SWAP_HALVES
  w = (w >> 16) | (w << 16);
#endif
  return w;
}

// 8 font pixels -> 8 nibbles, leftmost pixel in the top nibble (first bit out)
static uint32_t vidExpand(uint8_t bits) {
  uint32_t w = 0;
  for (int i = 0; i < 8; i++) {
    w = (w << 4) | ((bits & (0x80 >> i)) ? VID_NIB_WHITE : VID_NIB_BLACK);
  }
  return w;
}

static uint32_t vidBlackWord() {
  uint32_t w = 0;
  for (int i = 0; i < 8; i++) w = (w << 4) | VID_NIB_BLACK;
  return w;
}

static void vidDrawCell(int row, int col, char ch) {
  uint8_t c = (uint8_t)ch;
  if (c < 32 || c > 126) c = ' ';
  const uint8_t* glyph = &VID_FONT[(c - 32) * 8];
  for (int g = 0; g < 8; g++) {
    vidText[row * 8 + g][VID_ACT_W + col] = vidFix(vidExpand(pgm_read_byte(glyph + g)));
  }
}

// Copy screenBuf to the video buffers (only cells that changed).
void videoDraw() {
  if (!vidRunning) return;
  for (int r = 0; r < ROWS; r++) {
    for (int c = 0; c < COLS; c++) {
      char ch = screenBuf[r][c];
      if (vidShadow[r][c] != ch) {
        vidShadow[r][c] = ch;
        vidDrawCell(r, c, ch);
      }
    }
  }
}

bool videoRunning() {
  return vidRunning;
}

void videoBegin() {
  if (vidRunning) return;

  // ---- scanline contents ----
  uint32_t black = vidFix(vidBlackWord());
  for (int w = 0; w < VID_WORDS; w++) {
    uint32_t v = (w < VID_SYNC_W) ? 0 : black;       // normal line: sync, then black
    vidBlank[w] = v;
    vidVsync[w] = (w < VID_WORDS - 3) ? 0 : black;   // broad sync pulse, 4.8 us serration at the end
    for (int l = 0; l < VID_TEXT_LINES; l++) vidText[l][w] = v;
  }
  memset(vidShadow, 0, sizeof(vidShadow));            // forces a full redraw on first videoDraw()

  // ---- descriptor ring: one descriptor per scanline ----
  for (int l = 0; l < VID_LINES; l++) {
    uint32_t* buf;
    if (l < VID_VSYNC_LINES) {
      buf = vidVsync;
    } else if (l >= VID_ACTIVE_FIRST && l < VID_ACTIVE_FIRST + VID_TEXT_LINES * 2) {
      buf = vidText[(l - VID_ACTIVE_FIRST) / 2];     // each text scanline is shown twice
    } else {
      buf = vidBlank;
    }
    vidDesc[l].unused = 0;
    vidDesc[l].owner = 1;
    vidDesc[l].eof = 1;
    vidDesc[l].sub_sof = 0;
    vidDesc[l].datalen = VID_WORDS * 4;
    vidDesc[l].blocksize = VID_WORDS * 4;
    vidDesc[l].buf_ptr = buf;
    vidDesc[l].next_link_ptr = &vidDesc[(l + 1) % VID_LINES];
  }
  vidDummy.unused = 0;
  vidDummy.owner = 1;
  vidDummy.eof = 1;
  vidDummy.sub_sof = 0;
  vidDummy.datalen = sizeof(vidDummyBuf);
  vidDummy.blocksize = sizeof(vidDummyBuf);
  vidDummy.buf_ptr = vidDummyBuf;
  vidDummy.next_link_ptr = &vidDummy;

  // ---- SLC DMA (same sequence as the Arduino core's i2s driver, minus its ISR) ----
  pinMode(3, FUNCTION_1);                              // GPIO3 = I2SO_DATA
  ETS_SLC_INTR_DISABLE();
  SLCC0 |= SLCRXLR | SLCTXLR;
  SLCC0 &= ~(SLCRXLR | SLCTXLR);
  SLCIC = 0xFFFFFFFF;
  SLCC0 &= ~(SLCMM << SLCM);
  SLCC0 |= (1 << SLCM);
  SLCRXDC |= SLCBINR | SLCBTNR;
  SLCRXDC &= ~(SLCBRXFE | SLCBRXEM | SLCBRXFM);
  SLCTXL &= ~(SLCTXLAM << SLCTXLA);
  SLCRXL &= ~(SLCRXLAM << SLCRXLA);
  SLCTXL |= (uint32_t)&vidDummy << SLCTXLA;
  SLCRXL |= (uint32_t)&vidDesc[0] << SLCRXLA;         // "RX" link = memory -> I2S transmitter
  SLCIE = 0;                                           // no interrupts: the ring just spins
  SLCTXL |= SLCTXLS;
  SLCRXL |= SLCRXLS;

  // ---- I2S transmitter ----
  I2S_CLK_ENABLE();
  I2SIC = 0x3F;
  I2SIE = 0;
  I2SC &= ~(I2SRST);
  I2SC |= I2SRST;
  I2SC &= ~(I2SRST);
  I2SFC &= ~(I2SDE | (I2STXFMM << I2STXFM) | (I2SRXFMM << I2SRXFM));
  I2SFC |= I2SDE;
  I2SCC &= ~((I2STXCMM << I2STXCM) | (I2SRXCMM << I2SRXCM));

  uint32_t c = I2SC;
  c |= I2STXR;
  I2SC = c;
  c &= ~(I2STSM | I2SRSM | (I2SBMM << I2SBM) | (I2SBDM << I2SBD) | (I2SCDM << I2SCD));
  c |= I2SRF | I2SMR | I2SRMS | I2STMS | (VID_BCK_DIV << I2SBD) | (VID_CLKM_DIV << I2SCD);
  I2SC = c;
  c &= ~I2STXR;
  I2SC = c;
  I2SC |= I2STXS;                                      // go

  vidRunning = true;
}

// =====================================================================
// Serial commands
// =====================================================================

void printHelp() {
  Serial.println("Commands:");
  Serial.println("  ssid <network name>          set WiFi name (spaces ok)");
  Serial.println("  pass <password>              set WiFi password");
  Serial.println("  loc City, State, Country     e.g. loc Austin, TX, US");
  Serial.println("  latlon <lat> <lon>           set location by coordinates");
  Serial.println("  units f|c                    Fahrenheit or Celsius");
  Serial.println("  show                         show saved settings");
  Serial.println("  screen                       print the dashboard now");
  Serial.println("  live                         toggle once-per-second refresh");
  Serial.println("  weather                      refresh weather now");
  Serial.println("  video                        start composite video on GPIO3 (serial input stops until reboot)");
  Serial.println("  wipe                         erase all settings and reboot");
  Serial.println("  reboot                       restart the board");
}

void showConfig() {
  Serial.printf("SSID:     %s\r\n", cfg.ssid[0] ? cfg.ssid : "(not set)");
  Serial.printf("Password: %s\r\n", cfg.pass[0] ? "(set)" : "(not set)");
  Serial.printf("Location: %s, %s, %s\r\n", cfg.city, cfg.state, cfg.country);
  Serial.printf("Lat/Lon:  %.4f, %.4f (%s)\r\n", cfg.lat, cfg.lon,
                cfg.haveLoc ? "resolved" : "not resolved yet");
  Serial.printf("Units:    %s\r\n", cfg.fahrenheit ? "Fahrenheit" : "Celsius");
  Serial.printf("WiFi:     %s\r\n", WiFi.status() == WL_CONNECTED ? "connected" : "not connected");
}

void handleCommand(String line) {
  line.trim();
  if (line.length() == 0) return;
  String cmd = line;
  String arg = "";
  int sp = line.indexOf(' ');
  if (sp > 0) {
    cmd = line.substring(0, sp);
    arg = line.substring(sp + 1);
    arg.trim();
  }
  cmd.toLowerCase();

  if (cmd == "help" || cmd == "?") {
    printHelp();
  } else if (cmd == "ssid") {
    copyStr(cfg.ssid, sizeof(cfg.ssid), arg);
    saveConfig();
    WiFi.disconnect();
    triedWifi = false;
    Serial.println("SSID saved.");
  } else if (cmd == "pass") {
    copyStr(cfg.pass, sizeof(cfg.pass), arg);
    saveConfig();
    WiFi.disconnect();
    triedWifi = false;
    Serial.println("Password saved.");
  } else if (cmd == "loc") {
    String parts[3];
    int count = 0;
    int start = 0;
    while (count < 3) {
      int c = arg.indexOf(',', start);
      String p = (c < 0) ? arg.substring(start) : arg.substring(start, c);
      p.trim();
      parts[count++] = p;
      if (c < 0) break;
      start = c + 1;
    }
    if (parts[0].length() == 0) {
      Serial.println("Usage: loc City, State, Country");
      return;
    }
    copyStr(cfg.city, sizeof(cfg.city), parts[0]);
    copyStr(cfg.state, sizeof(cfg.state), parts[1]);
    copyStr(cfg.country, sizeof(cfg.country), parts[2]);
    cfg.haveLoc = 0;
    saveConfig();
    haveWx = false;
    needGeocode = true;
    wxStatus = "Loading weather...";
    Serial.println("Location saved. It will be looked up once WiFi is connected.");
  } else if (cmd == "latlon") {
    arg.replace(",", " ");
    arg.trim();
    int s2 = arg.indexOf(' ');
    if (s2 < 1) {
      Serial.println("Usage: latlon 30.27 -97.74");
      return;
    }
    cfg.lat = arg.substring(0, s2).toFloat();
    cfg.lon = arg.substring(s2 + 1).toFloat();
    cfg.haveLoc = 1;
    cfg.city[0] = 0;
    cfg.state[0] = 0;
    cfg.country[0] = 0;
    saveConfig();
    haveWx = false;
    needGeocode = false;
    forceRefresh = true;
    wxStatus = "Loading weather...";
    Serial.println("Coordinates saved.");
  } else if (cmd == "units") {
    arg.toLowerCase();
    if (arg == "f") {
      cfg.fahrenheit = 1;
    } else if (arg == "c") {
      cfg.fahrenheit = 0;
    } else {
      Serial.println("Usage: units f   or   units c");
      return;
    }
    saveConfig();
    forceRefresh = true;
    Serial.println("Units saved.");
  } else if (cmd == "show") {
    showConfig();
  } else if (cmd == "screen") {
    buildScreen();
    printScreen(false);
  } else if (cmd == "live") {
    liveMode = !liveMode;
    Serial.println(liveMode ? "Live mode on (type live to turn off)." : "Live mode off.");
  } else if (cmd == "weather") {
    forceRefresh = true;
    Serial.println("Refreshing weather...");
  } else if (cmd == "video") {
    if (videoRunning()) {
      Serial.println("Video is already running.");
    } else {
      Serial.println("Starting video on GPIO3. Serial input stops until reset.");
      Serial.flush();
      buildScreen();
      videoBegin();
      videoDraw();
      lastVid = millis();
    }
  } else if (cmd == "wipe") {
    memset(&cfg, 0, sizeof(cfg));
    saveConfig();
    Serial.println("Settings erased. Rebooting.");
    delay(200);
    ESP.restart();
  } else if (cmd == "reboot") {
    Serial.println("Rebooting.");
    delay(200);
    ESP.restart();
  } else {
    Serial.println("Unknown command. Type help.");
  }
}

void readSerial() {
  while (Serial.available()) {
    uint8_t c = Serial.read();
    if (c == '\r' || c == '\n') {
      if (lineBuf.length()) {
        Serial.println();
        String l = lineBuf;
        lineBuf = "";
        handleCommand(l);
      }
    } else if (c == 8 || c == 127) {
      if (lineBuf.length()) {
        lineBuf.remove(lineBuf.length() - 1);
        Serial.print("\b \b");
      }
    } else if (c >= 32 && lineBuf.length() < 120) {
      lineBuf += (char)c;
      Serial.write(c);
    }
  }
}

// =====================================================================
// Arduino entry points
// =====================================================================

void setup() {
  Serial.begin(115200);
  delay(200);
  EEPROM.begin(512);
  loadConfig();
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  if (!cfg.haveLoc && cfg.city[0]) needGeocode = true;
  lastDraw = millis() - 55000UL;   // first dashboard print about 5 s after boot
  Serial.println();
  Serial.println("Weather clock ready. Type help.");

  // GPIO3 is both serial RX and the video pin, so give serial a chance first.
  Serial.println("Press Enter within 5 s for setup mode (keeps serial input, video off).");
  unsigned long t0 = millis();
  bool setupMode = false;
  while (millis() - t0 < 5000UL) {
    if (Serial.available()) {
      setupMode = true;
      break;
    }
    delay(10);
  }
  if (setupMode) {
    Serial.println("Setup mode. Type 'video' when done to start the picture.");
  } else {
    Serial.println("Starting video on GPIO3 (serial input is off until reset).");
    Serial.flush();
    buildScreen();
    videoBegin();
    videoDraw();
    lastVid = millis();
  }
}

void loop() {
  readSerial();
  unsigned long ms = millis();

  if (WiFi.status() != WL_CONNECTED) {
    wasConnected = false;
    if (cfg.ssid[0] && (!triedWifi || ms - lastWifiTry > 20000UL)) {
      triedWifi = true;
      lastWifiTry = ms;
      WiFi.mode(WIFI_STA);
      WiFi.begin(cfg.ssid, cfg.pass);
      Serial.printf("\r\nConnecting to %s...\r\n", cfg.ssid);
    }
  } else {
    if (!wasConnected) {
      wasConnected = true;
      Serial.printf("\r\nWiFi connected, IP %s\r\n", WiFi.localIP().toString().c_str());
      configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    }
    if (needGeocode) {
      needGeocode = false;
      if (geocode()) {
        forceRefresh = true;
      } else {
        wxStatus = "Location lookup failed";
      }
    }
    if (cfg.haveLoc) {
      if (forceRefresh) {
        forceRefresh = false;
        nextFetchAt = ms;
      }
      if ((long)(ms - nextFetchAt) >= 0) {
        if (fetchWeather()) {
          nextFetchAt = ms + REFRESH_MS;
        } else {
          nextFetchAt = ms + 60000UL;   // retry in a minute
        }
      }
    }
  }

  if (videoRunning() && ms - lastVid >= 1000UL) {
    lastVid = ms;
    buildScreen();
    videoDraw();
  }

  unsigned long interval = liveMode ? 1000UL : 60000UL;
  if (ms - lastDraw >= interval) {
    lastDraw = ms;
    buildScreen();
    printScreen(liveMode);
  }
}
