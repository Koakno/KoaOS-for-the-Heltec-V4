# WeatherClock

An ESP8266 desk clock and weather dashboard that outputs **composite video** (RCA) to a small LCD. It was built to drive the fold-out display from a Sony Handycam CCD-FX730V. For the display itself (pinout, power, wiring), see [PD-53-LCD-README.md](PD-53-LCD-README.md).

- Shows location, time and date, current conditions, and a multi-day forecast on a 32x12 character screen.
- Weather and geocoding come from Open-Meteo (free, no API key). Time comes from NTP.
- Weather refreshes every 15 minutes (retries after 1 minute on failure).
- Settings are saved in EEPROM, so you only enter WiFi and location once.

## Video output

The video signal comes out of **GPIO3**, which is the **RX pin** on a NodeMCU. It is driven by the I2S peripheral and DMA, so WiFi and HTTPS activity never disturb the picture.

| Property | Value |
|---|---|
| Format | Monochrome NTSC-style, 262 lines, about 59.6 Hz (15.625 kHz line rate) |
| Resolution | 256 px wide, 32 columns x 12 rows of 8x8 text |
| Bit stream | 20 Mbit/s pulse-density on one pin |
| Levels | Sync 0%, black 50%, white 100% |
| RAM used | About 20 KB |

### Wiring

```
GPIO3 (RX) ---[ ~100 ohm ]--- pot end 1
                              pot wiper ---------- RCA center pin (to LCD video in)
GND ------------------------- pot end 2 ---------- RCA shield (ground)
```

- The potentiometer is a voltage divider. The wiper position sets signal amplitude, which acts as contrast and brightness together. Find the spot where the picture is clean and leave it.
- The LCD's own brightness knob (RV001 on the PD-53 board) is a separate control.
- The fixed ~100 ohm resistor ahead of the pot is optional. It only limits pin current if the pot is turned all the way to the GPIO3 end into a 75 ohm input.
- There is no dedicated filter capacitor. The pot's source resistance and the stray capacitance of the cable and LCD input act as the low-pass filter. If the black areas look hatched, add 470 pF to 1 nF from the wiper to ground.
- Keep the wires between GPIO3, the pot, and the jack short.

### GPIO3 is also the serial RX pin

While video is running, serial input is gone. Serial output on GPIO1 still works. Because of this, the board has a **5-second setup window** after every reset.

**USB-serial chip caution.** On a NodeMCU-style board, the on-board USB-serial chip's TX output is also connected to GPIO3, and its idle level is high. It can fight the video signal at the pin. The video worked fine in testing, but for permanent use it is safer to:

- power the board from the **VIN / 5V pin** with the micro-USB cable unplugged, and
- plug USB in only when you need to change settings.

## Setup mode

1. Connect the serial cable to your computer (115200 baud).
2. Press the reset button.
3. Press **Enter** within 5 seconds. Video stays off and serial input stays on.
4. Enter your settings (see the commands below).
5. Type `video` to start the picture, or `reboot` to restart. Serial input then stops until the next reset.

If you do nothing in the 5 seconds, video starts on its own and serial input stops until the next reset.

## Serial commands

Type these in setup mode. Settings are saved automatically.

| Command | What it does |
|---|---|
| `help` or `?` | List the commands |
| `ssid <network name>` | Set the WiFi name (spaces are fine) |
| `pass <password>` | Set the WiFi password |
| `loc City, State, Country` | Set the location by name, for example `loc Austin, TX, US` |
| `latlon <lat> <lon>` | Set the location by coordinates |
| `units f` or `units c` | Fahrenheit or Celsius |
| `show` | Show the saved settings |
| `screen` | Print the dashboard to the terminal now |
| `live` | Toggle a once-per-second dashboard refresh in the terminal |
| `weather` | Refresh the weather now |
| `video` | Start composite video on GPIO3 (serial input stops until reset) |
| `wipe` | Erase all settings and reboot |
| `reboot` | Restart the board |

The WiFi password is stored as plain text in the board's flash.

## Build notes

- Board: NodeMCU (ESP8266) with the Arduino ESP8266 core, version 2.5 or newer.
- Test pattern: set `VIDEO_TEST_PATTERN` to `1` in the sketch to show a character grid instead of the weather, which is useful for checking sync and levels.
- If characters look mirrored, set `VID_REVERSE_BITS` to `1`. If each character's halves look swapped, set `VID_SWAP_HALVES` to `1`.
- Black level is `VID_NIB_BLACK`. The default `0x5` (50%) keeps the ripple at a high frequency that filters easily. `0x4` (25%) gives more contrast, is closer to standard video levels (where sync is roughly 40% of the video swing), but has a harder-to-filter ripple. Worth trying on a display that is fussy about sync.
- The TLS fetch uses small buffers when the server supports it, to leave enough heap next to the video buffers.
- The 8x8 font data comes from the CP437 font in luma.core (MIT license).

## Case plan

- Power through the board's VIN / 5V pin (or a dedicated USB power cable), with a separate cable for configuration.
- Pot on the back panel with a small knob.
- External reset button wired between RST and GND.
